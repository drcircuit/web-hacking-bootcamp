<?php
// config.php
$jwt_secret = 'evilcorp';
// Flag: WCH{config_flag} Hint: Check system files like /etc/passwd or /etc/shadow for sensitive information.

?>

WCH{config_found_lfi_your_way_in}