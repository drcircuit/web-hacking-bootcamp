#!/bin/bash
service ssh start
/usr/sbin/apache2ctl -D FOREGROUND